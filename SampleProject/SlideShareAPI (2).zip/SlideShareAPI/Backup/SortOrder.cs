﻿namespace SlideShareAPI
{
    public enum SortOrder
    {
        relevance, mostviewed, mostdownloaded, latest
    }
}
