﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;

namespace SlideShareAPI
{
    public static class GetCommand
    {
        public static string Execute(string url, ICollection<KeyValuePair<string, object>> parameters)
        {
            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string responseXml=string.Empty;
            try
            {
                responseXml += "******************************************************************************************************";
                responseXml += "callig request  with TLS ::: " + Environment.NewLine + System.Net.ServicePointManager.SecurityProtocol.ToString() + Environment.NewLine;
                var request = WebRequest.Create(url + "?" + Helper.CreateFormattedRequest(parameters)) as HttpWebRequest;


                responseXml += "Request  " + request.Address.AbsoluteUri  + Environment.NewLine;
                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    var reader = new StreamReader(response.GetResponseStream());
                    responseXml += " Content: " + reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                //this MessageToLog variable need to initialize before this block and need to be logged at the end of catch block in your logs

                responseXml += " Exception : LEVEL 1: " + Environment.NewLine + ex.Message + "STACK :" + ex.StackTrace;
                if (ex.InnerException != null)
                {
                    responseXml += Environment.NewLine + "LEVEL 2:" + Environment.NewLine + ex.InnerException.Message + "STACK :" + ex.InnerException.StackTrace;
                    if (ex.InnerException.InnerException != null)
                    {
                        responseXml += Environment.NewLine + "LEVEL 3:" + Environment.NewLine + ex.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.StackTrace;

                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            responseXml += Environment.NewLine + "LEVEL 4:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.StackTrace;
                            if (ex.InnerException.InnerException.InnerException.InnerException != null)
                            {
                                responseXml += Environment.NewLine + "LEVEL 5:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.InnerException.StackTrace;
                            }
                        }
                    }
                }

            }
            return responseXml;
        }
        public static string ExecuteTLSRaw(string url, ICollection<KeyValuePair<string, object>> parameters)
        {
            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            
            string responseXml = string.Empty;
            try
            {
           

                responseXml += "******************************************************************************************************";
                responseXml += "callig request  with TLS ::: " + Environment.NewLine + System.Net.ServicePointManager.SecurityProtocol.ToString() + Environment.NewLine;
                var request = WebRequest.Create(url + "?" + Helper.CreateFormattedRequest(parameters)) as HttpWebRequest;


                //Altenet call goes here
                //responseXml += "Request  " + request.Address.AbsoluteUri + Environment.NewLine;

                //HttpClient client = new HttpClient();
                //var TARGETURL = request.Address.AbsoluteUri;
                //client.BaseAddress = new Uri(TARGETURL);

                //HttpResponseMessage response1 = client.GetAsync(TARGETURL).Result;
                //HttpContent content = response1.Content;
                //string result = content.ReadAsStringAsync().Result;

                //responseXml += "Result from Default_Setting_for_TLS calls : " + result+Environment.NewLine;

                //Altenet call ends here

                responseXml += "******************************************************************************************************";
                responseXml += "Result from normal Call";
                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    var reader = new StreamReader(response.GetResponseStream());
                    responseXml += " Content: " + reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                //this MessageToLog variable need to initialize before this block and need to be logged at the end of catch block in your logs

                responseXml += " Exception : LEVEL 1: " + Environment.NewLine + ex.Message + "STACK :" + ex.StackTrace;
                if (ex.InnerException != null)
                {
                    responseXml += Environment.NewLine + "LEVEL 2:" + Environment.NewLine + ex.InnerException.Message + "STACK :" + ex.InnerException.StackTrace;
                    if (ex.InnerException.InnerException != null)
                    {
                        responseXml += Environment.NewLine + "LEVEL 3:" + Environment.NewLine + ex.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.StackTrace;

                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            responseXml += Environment.NewLine + "LEVEL 4:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.StackTrace;
                            if (ex.InnerException.InnerException.InnerException.InnerException != null)
                            {
                                responseXml += Environment.NewLine + "LEVEL 5:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.InnerException.StackTrace;
                            }
                        }
                    }
                }

            }
            return responseXml;
        }
        public static string ExecuteTLS(string url, ICollection<KeyValuePair<string, object>> parameters)
        {
            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
            string responseXml = string.Empty;
            try
            {


                responseXml += "******************************************************************************************************";
                responseXml += "callig request  with TLS ::: " + Environment.NewLine + System.Net.ServicePointManager.SecurityProtocol.ToString() + Environment.NewLine;
                var request = WebRequest.Create(url + "?" + Helper.CreateFormattedRequest(parameters)) as HttpWebRequest;


                //Altenet call goes here
                responseXml += "Request  " + request.Address.AbsoluteUri + Environment.NewLine;

                //HttpClient client = new HttpClient();
                //var TARGETURL = request.Address.AbsoluteUri;
                //client.BaseAddress = new Uri(TARGETURL);

                //HttpResponseMessage response1 = client.GetAsync(TARGETURL).Result;
                //HttpContent content = response1.Content;
                //string result = content.ReadAsStringAsync().Result;

                //responseXml += "Result from TLS setting as SecurityProtocolType.Tls in code calls : " + result + Environment.NewLine;

                //Altenet call ends here

                responseXml += "******************************************************************************************************";
                responseXml += "Result from normal Call";
                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    var reader = new StreamReader(response.GetResponseStream());
                    responseXml += " Content: " + reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                //this MessageToLog variable need to initialize before this block and need to be logged at the end of catch block in your logs

                responseXml += " Exception : LEVEL 1: " + Environment.NewLine + ex.Message + "STACK :" + ex.StackTrace;
                if (ex.InnerException != null)
                {
                    responseXml+=  Environment.NewLine + "LEVEL 2:" + Environment.NewLine + ex.InnerException.Message + "STACK :"+  ex.InnerException.StackTrace;
                    if (ex.InnerException.InnerException != null)
                    {
                        responseXml += Environment.NewLine + "LEVEL 3:" + Environment.NewLine + ex.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.StackTrace;

                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            responseXml+=  Environment.NewLine + "LEVEL 4:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.Message+ "STACK :" + ex.InnerException.InnerException.InnerException.StackTrace;
                            if (ex.InnerException.InnerException.InnerException.InnerException != null)
                            {
                                responseXml +=  Environment.NewLine + "LEVEL 5:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.InnerException.StackTrace;
                            }
                        }
                    }
                }

            }

            return responseXml;
        }
        public static string ExecuteTLS11(string url, ICollection<KeyValuePair<string, object>> parameters)
        {
            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11;
            string responseXml = string.Empty;
            try
            {


                responseXml += "******************************************************************************************************";
                responseXml += "callig request  with TLS ::: " + Environment.NewLine + System.Net.ServicePointManager.SecurityProtocol.ToString() + Environment.NewLine;
                var request = WebRequest.Create(url + "?" + Helper.CreateFormattedRequest(parameters)) as HttpWebRequest;


                //Altenet call goes here
                //responseXml += "Request  " + request.Address.AbsoluteUri + Environment.NewLine;

                //HttpClient client = new HttpClient();
                //var TARGETURL = request.Address.AbsoluteUri;
                //client.BaseAddress = new Uri(TARGETURL);

                //HttpResponseMessage response1 = client.GetAsync(TARGETURL).Result;
                //HttpContent content = response1.Content;
                //string result = content.ReadAsStringAsync().Result;

                //responseXml += "Result from TLS setting as SecurityProtocolType.Tls11 in code calls : " + result + Environment.NewLine;

                //Altenet call ends here

                responseXml += "******************************************************************************************************";
                responseXml += "Result from normal Call";
                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    var reader = new StreamReader(response.GetResponseStream());
                    responseXml += " Content: " + reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                //this MessageToLog variable need to initialize before this block and need to be logged at the end of catch block in your logs

                responseXml += " Exception : LEVEL 1: " + Environment.NewLine + ex.Message + "STACK :" + ex.StackTrace;
                if (ex.InnerException != null)
                {
                    responseXml += Environment.NewLine + "LEVEL 2:" + Environment.NewLine + ex.InnerException.Message + "STACK :" + ex.InnerException.StackTrace;
                    if (ex.InnerException.InnerException != null)
                    {
                        responseXml += Environment.NewLine + "LEVEL 3:" + Environment.NewLine + ex.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.StackTrace;

                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            responseXml += Environment.NewLine + "LEVEL 4:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.StackTrace;
                            if (ex.InnerException.InnerException.InnerException.InnerException != null)
                            {
                                responseXml += Environment.NewLine + "LEVEL 5:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.InnerException.StackTrace;
                            }
                        }
                    }
                }

            }
            return responseXml;
        }
        public static string ExecuteTLS12(string url, ICollection<KeyValuePair<string, object>> parameters)
        {
            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string responseXml = string.Empty;
            try
            {


                responseXml += "******************************************************************************************************";
                responseXml += "callig request  with TLS ::: " + Environment.NewLine + System.Net.ServicePointManager.SecurityProtocol.ToString() + Environment.NewLine;
                var request = WebRequest.Create(url + "?" + Helper.CreateFormattedRequest(parameters)) as HttpWebRequest;


                ////Altenet call goes here
                //responseXml += "Request  " + request.Address.AbsoluteUri + Environment.NewLine;

                //HttpClient client = new HttpClient();
                //var TARGETURL = request.Address.AbsoluteUri;
                //client.BaseAddress = new Uri(TARGETURL);

                //HttpResponseMessage response1 = client.GetAsync(TARGETURL).Result;
                //HttpContent content = response1.Content;
                //string result = content.ReadAsStringAsync().Result;

                //responseXml += "Result from TLS setting as SecurityProtocolType.Tls12 in code calls : " + result + Environment.NewLine;

                //Altenet call ends here

                responseXml += "******************************************************************************************************";
                responseXml += "Result from normal Call";
                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    var reader = new StreamReader(response.GetResponseStream());
                    responseXml += " Content: " + reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                //this MessageToLog variable need to initialize before this block and need to be logged at the end of catch block in your logs

                responseXml += " Exception : LEVEL 1: " + Environment.NewLine + ex.Message + "STACK :" + ex.StackTrace;
                if (ex.InnerException != null)
                {
                    responseXml += Environment.NewLine + "LEVEL 2:" + Environment.NewLine + ex.InnerException.Message + "STACK :" + ex.InnerException.StackTrace;
                    if (ex.InnerException.InnerException != null)
                    {
                        responseXml += Environment.NewLine + "LEVEL 3:" + Environment.NewLine + ex.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.StackTrace;

                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            responseXml += Environment.NewLine + "LEVEL 4:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.StackTrace;
                            if (ex.InnerException.InnerException.InnerException.InnerException != null)
                            {
                                responseXml += Environment.NewLine + "LEVEL 5:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.InnerException.StackTrace;
                            }
                        }
                    }
                }

            }
            return responseXml;
        }
        public static string ExecuteTLSSSL3(string url, ICollection<KeyValuePair<string, object>> parameters)
        {
            //System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;
            string responseXml = string.Empty;
            try
            {


                responseXml += "******************************************************************************************************";
                responseXml += "callig request  with TLS ::: " + Environment.NewLine + System.Net.ServicePointManager.SecurityProtocol.ToString() + Environment.NewLine;
                var request = WebRequest.Create(url + "?" + Helper.CreateFormattedRequest(parameters)) as HttpWebRequest;


                ////Altenet call goes here
                //responseXml += "Request  " + request.Address.AbsoluteUri + Environment.NewLine;

                //HttpClient client = new HttpClient();
                //var TARGETURL = request.Address.AbsoluteUri;
                //client.BaseAddress = new Uri(TARGETURL);

                //HttpResponseMessage response1 = client.GetAsync(TARGETURL).Result;
                //HttpContent content = response1.Content;
                //string result = content.ReadAsStringAsync().Result;

                //responseXml += "Result from TLS setting as SecurityProtocolType.Tls12 in code calls : " + result + Environment.NewLine;

                //Altenet call ends here

                responseXml += "******************************************************************************************************";
                responseXml += "Result from normal Call";
                using (var response = request.GetResponse() as HttpWebResponse)
                {
                    var reader = new StreamReader(response.GetResponseStream());
                    responseXml += " Content: " + reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                //this MessageToLog variable need to initialize before this block and need to be logged at the end of catch block in your logs

                responseXml += " Exception : LEVEL 1: " + Environment.NewLine + ex.Message + "STACK :" + ex.StackTrace;
                if (ex.InnerException != null)
                {
                    responseXml += Environment.NewLine + "LEVEL 2:" + Environment.NewLine + ex.InnerException.Message + "STACK :" + ex.InnerException.StackTrace;
                    if (ex.InnerException.InnerException != null)
                    {
                        responseXml += Environment.NewLine + "LEVEL 3:" + Environment.NewLine + ex.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.StackTrace;

                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            responseXml += Environment.NewLine + "LEVEL 4:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.StackTrace;
                            if (ex.InnerException.InnerException.InnerException.InnerException != null)
                            {
                                responseXml += Environment.NewLine + "LEVEL 5:" + Environment.NewLine + ex.InnerException.InnerException.InnerException.InnerException.Message + "STACK :" + ex.InnerException.InnerException.InnerException.InnerException.StackTrace;
                            }
                        }
                    }
                }

            }
            return responseXml;
        }
    }
}
